//
//  MinislideViewController.swift
//  SideMenuTutorial
//
//  Created by adithya on 10/3/18.
//  Copyright © 2018 Kyle Suchar. All rights reserved.
//

import UIKit

class MinislideViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func share(_ sender: Any) {
        
        let activityVC = UIActivityViewController(activityItems: ["https://play.google.com/store/apps/details?id=com.nirvanza"], applicationActivities: nil)
        activityVC.popoverPresentationController?.sourceView = self.view
        self.present(activityVC, animated: true, completion: nil)
        
    }

}
