//
//  ServicesWebViewController.swift
//  SideMenuTutorial
//
//  Created by adithya on 9/6/18.
//  Copyright © 2018 Kyle Suchar. All rights reserved.
//

import UIKit

class ServicesWebViewController: UIViewController {
    var vv = String()
    var vvv = String()
    var vvvv = String()
    
    @IBOutlet weak var i1: UIImageView!
    
    @IBOutlet weak var l1: UILabel!
    @IBOutlet weak var t1: UITextView!
    
    
    

    @IBOutlet weak var myWebView: UIWebView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
//        customizeNavBar()
//
//        let url = URL(string: vv)
//        myWebView.loadRequest(URLRequest(url: url!))
    }
//    @IBAction func back(_ sender: Any) {
//        navigationController?.popViewController(animated: true)
//        dismiss(animated: true, completion: nil)
//    }
    
    override func viewWillAppear(_ animated: Bool) {
        customizeNavBar()
        
        i1.image = UIImage(named: vv)
        l1.text = vvv
        t1.text = vvvv
     //   let url = URL(string: vv)
        //myWebView.loadRequest(URLRequest(url: url!))
    }
    override var preferredStatusBarStyle: UIStatusBarStyle{
        
        return .lightContent
    }
    func customizeNavBar() {
        
        
        navigationController?.navigationBar.tintColor = UIColor(colorLiteralRed: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        navigationController?.navigationBar.barTintColor = UIColor(colorLiteralRed: 17/255, green: 94/255, blue: 41/255, alpha: 1)
        
        navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: UIColor.white]
        
        
    }
}
