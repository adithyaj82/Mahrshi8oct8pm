//
//  ServicesViewController.swift
//  SideMenuTutorial
//
//  Created by adithya on 9/6/18.
//  Copyright © 2018 Kyle Suchar. All rights reserved.
//

import UIKit

class ServicesViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        customizeNavBar()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func customizeNavBar() {
        
        
        navigationController?.navigationBar.tintColor = UIColor(colorLiteralRed: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        navigationController?.navigationBar.barTintColor = UIColor(colorLiteralRed: 17/255, green: 94/255, blue: 41/255, alpha: 1)
        
        navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: UIColor.white]
        
        
    }
    
    @IBAction func astrology(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesWebViewController")as! ServicesWebViewController
       // vc.vv = "http://vastushastraexperts.com/astrology-in-ahmedabad.html";
        vc.vv = "astrology.png"
       vc.vvv = "ASTROLOGY"
        vc.vvvv = "Life is very uncertain.When science cannot answer the uncertainties of a person's life, then the person falls for astrology,which is regarded as a pseudoscience or quackery or quick money making strategy.But we should not come to any conclusion before we are much acquainted with astrology.\n\nAstrology believes that our lives are influenced, our personalities are shaped, and the future course that our lives will take depends on how the celestial bodies, such as the sun, the moon, the stars and the planets, are placed when we are born.\nAstrology is, put simply, the study of the correlation between the astronomical positions of the planets and events on earth. Astrologers believe that the positions of the Sun, Moon, and planets at the time of a person's birth have a direct influence on that person's character. These positions are thought to affect a person's destiny, although many Astrologers feel that free will plays a large role in any individual's life.\n\nMr. Amit Parikh Is One Of The Best Astrologer In Ahmedabad Who Provides The Solutions Through His Astrology Knowledge Like\n• Love problems\n• Financial problems\n• Health problems\n• Children problems\n• For starting new business\n• For partnership\n• For hiring employees\n• For getting job\n• For education of children\n• For selecting business\n\nYou can contact on +91 98985 44441 Or Mail On mahrshivastu@gmail.com and discuss your problem and you will receive Proper Vastu Guidance Online via email."
self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    @IBAction func numerology(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesWebViewController")as! ServicesWebViewController
      //  vc.vv = "http://vastushastraexperts.com/numerology-in-ahmedabad.html";
        vc.vv = "numerology.jpg"
        vc.vvv = "NUMEROLOGY"
        vc.vvvv = "Mr. Amit Parik is very popular in Numeorology Astrologer in Ahmedabad, Gujarat. Basically Numerology express a great details about a person's life path, character, materialistic and spiritual development in life, career, romantic characteristics, health, destiny and talent. By using Numerology techniques it is possible to determine the best time for major activity of life.\n\nNumerology is often associated with the paranormal, alongside astrology and similar divinatory arts. Everything during this universe has its own vibration. Field of study calculation of a person?s name and birth date helps to spot the main frequencies of that person. Each alphabet of the name has a certain value, and the sum total of this value should be in harmony with your date of birth to have happy life.\n\nIf your name produces powerful and strong numerical values having compatibility with your birth date, it would lead to a powerful and strong internal vibration or else it may lead to the destruction of external relations as a cascading effect. Every number have some vibrations which related to our life. Since our birth we have numbers in form of our birth date. Our names are also a very Important tool for Numerology experts. Each letters has a numeric value or frequency that relates to its vibrations. The sum of numbers in our birth date and sum of value derived from letters in our name provide a road map of vibrations.\nThis very wrong concept that numerology don't need time of birth and place of birth. These both information's are required to find more accurate and detailed readings.\n\nMr. Amit Parik Are Giving A Key Feature Of Numbers Below :\n1.(one ) Individual; aggressor; self; leadership yang\n2.(Two )Balance; union; receptive; partnership yin\n3.(Three )Communication/interaction\n4.(Four )Creation\n5.(Five)Action; restlessness; life experience\n6.(Six )Home/family; responsibility; artistic in nature\n7.(Seven)(one )Thought/consciousness; spirit\n8.(Eight )Power/sacrifice\n9.(Nine )Highest level of changes\n\nAlphabetic Systems :\nnumbers are assigned to letters as follows:\n1 = a, j, s\n2 = b, k, t,\n3 = c, l, u,\n4 = d, m, v,\n5 = e, n, w,\n6 = f, o, x,\n7 = g, p, y,\n8 = h, q, z,\n9 = i, r,\n-----and then summed.\n\nAs A Numerologist In Ahmedabad Mr. Amit PArikh Specialsit For :\n• Baby Name Numerology\n• Business Name Numerology\n• Marriage Numerology\n• Mobile Number Numerology\n• Vehicle Number Numerology\n• Bank Account Number Numerology\n• Name Numerology\n• Numerology Courses in Bangalore\n• Name Correction in Numerology\n• Business and Partnership Numerology\n• New Product Name as per Numerology\n• Movie Name as per Numerology\n• TV Show and TV Serial Names as per Numerology\n• Job Numerology\n• Numerology Training in Bangalore\n• Education Numerology\n• Health Numerology\n\nYou can contact on +91 98985 44441 Or Mail On mahrshivastu@gmail.com and discuss your problem and you will receive Proper Vastu Guidance Online via email."
self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    @IBAction func horoscope(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesWebViewController")as! ServicesWebViewController
        //vc.vv = "http://vastushastraexperts.com/horoscope-in-ahmedabad.html";
        vc.vv = "horosocpe.jpg"
        vc.vvv = "HOROSCOPE"
        vc.vvvv = "Astrology most often consists of a system of horoscopes purporting to explain aspects of a person's personality and predict future events in their life based on the positions of the sun, moon, and other celestial objects at the time of their birth.\n\nA horoscope is an astrological chart or diagram representing the positions of the Sun, Moon, planets, astrological aspects, and sensitive angles at the time of an event, such as the moment of a person's birth.\n\nAs a Horoscope Specialist Mr. Amit Parikh provides daily horoscopes, online tarot readings, psychic readings, Chinese astrology, Vedic Astrology, Mayan Astrology, Numerology, Fengshui ...\n\nTypes Of Horoscope\n• Natal Horoscope\n• Local Horoscope\n• Horary Horoscope\n• Mundane Horoscope\n• Karmic Horoscope\n• Love Horoscope\n• Yearly Horoscope\n• Monthly Horoscope\n• Weekly Horoscope\n• Daily Horoscope\n• Wellness Horoscope\n• Teen Horoscope\n• Food Horoscope\n• Career Horoscope\n• Birthday Horoscope\n• Celebrity Horoscope\n\nTopics Cover In Horoscope Predictions :\nHouse predictions about your Health, Finance, Marriage, Career etc.\nPlanet readings about 9 planets in your horoscope\n• Dasha readings\n• Yearly predictions\n• Yoga predictions\n• Numerology predictions\n• Nakshatra Reading\n• Lalkitab predictions\nHoroscope Predictions Remedies :\n• Gem Therapy\n• Sadesati\n• Kalsarp Dosh\n• Manglik Dosh\n• Pitra Dosh\n• Bhakoot Dosh\n• Chandra Dosh\n\nYou can contact on +91 98985 44441 Or Mail On mahrshivastu@gmail.com and discuss your problem and you will receive Proper Vastu Guidance Online via email."
self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    @IBAction func faceread(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesWebViewController")as! ServicesWebViewController
       // vc.vv = "http://vastushastraexperts.com/face-reading-in-ahmedabad.html";
        vc.vv = "facereading.jpg"
        vc.vvv = "FACE READING"
        vc.vvvv = "Face reading or physiognomy is a very fascinating technique where you interpret a person's personality traits, fate (past, present, future), as well as health condition – just by studying the face. Your face is the mirror of your personality. Statistical results have shown that there is a strong connection between facial features and personality traits.\n\n• Face Reading & Facial Features\n• Forehead Profile\n• Eye to Eyebrows Distance\n• Lip Size\n• Lip Line\n• Distance between the two eyes\n• Nose Shape and Size\n• The shape of the chin\n• Shape of eyebrows\n• The height of ears\n• Face shape\n• Ear shape\n• Ear position\n• Teeth shape\n• Face lines\n• Protruding cheek bones\nLeft & Right Sides of face\n• face proportions\n• Eye depth\n\n• Facial Shape\n•Round Face\n• Oblong Face\n• Triangular Face\n• Square Face\n•Rectangular Face\n• Oval Face\n\nHair\n• Blonde Hair\n• Black Hair\n• Brown Hair\n• Dark brown Hair\n• Red Hair\n• Dark red Hair\n• Bright red Hair\n• Pale red Hair\n\nEars\n• Small Ears\n• Big Ears\n• Ears with detached Earlobes\n\nYou can contact on +91 98985 44441 Or Mail On mahrshivastu@gmail.com and discuss your problem and you will receive Proper Vastu Guidance Online via email."
self.navigationController?.pushViewController(vc, animated: true)
        
    }
    @IBAction func kundli(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesWebViewController")as! ServicesWebViewController
       // vc.vv = "http://vastushastraexperts.com/kundli-matching-in-ahmedabad.html";
        vc.vv = "kundlimatch.jpg"
        vc.vvv = "KUNDLI MATCHING"
        vc.vvvv = "There Are Three Types Of Kundli\n\n• Lagna Kundli,\n• Chandra Kundli\n• Navamansa chart.\n• Details Required For Kundli\n• Date of Birth\nBirth Place\n• Exact Birth Time\n\nKindly Provides This Details Which Is Given Below For Kundli Matching For Male And Female.\n• Name\n• Email\n• Phone\n• Gender\n• Date of Birth\nTime of Birth\n• Place of Birth\n\nYou can contact on +91 98985 44441 Or Mail On mahrshivastu@gmail.com and discuss your problem and you will receive Proper Vastu Guidance Online via email."
self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    @IBAction func palm(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesWebViewController")as! ServicesWebViewController
        vc.vv = "palmreading.jpg"
        vc.vvv = "PALM READING"
        vc.vvvv = "Palm Reading is the art or practice of supposedly interpreting a person's character or predicting their future by examining the palm of their hand. Palmistry in that way can prove to be a mirror of the story of the life of an individual. Palmistry revolves around the study of main lines, secondary lines, lines of influence, mounts, shape of palm, thumb and fingers.\n\nIf you have any question about your life and you want it to read through palmistry then you are at right place. For getting consultancy through palmistry you have to send photograph of your palms.\n\nAfter sending photographs, you have following options and steps for getting answer of your questions:\n\n1. You can chat or talk by telephone. otherwise you may mail us by using same utility.\n\n2. If you want our advise by mail then you may mail us at following email ID`s\n\n3. We need following informations :\n• Date of birth(optional)\n• Time of Birth (optipnal)\n• Place of birth (optional)\n• Full name\n• Male or Female (optional)\n• Questions\nYour email ID\n• Alternate email ID\n• Details of payment.\n\nYou can contact on +91 98985 44441 Or Mail On mahrshivastu@gmail.com and discuss your problem and you will receive Proper Vastu Guidance Online via email."
        //  vc.vv = "http://vastushastraexperts.com/palm-reading-in-ahmedabad.html";
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    @IBAction func crystal(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesWebViewController")as! ServicesWebViewController
        vc.vv = "crystaltherapy.jpg"
        vc.vvv = "CRYSTAL THERAPY"
        vc.vvvv = "Crystal therapy is an ancient healing system concerned with treating patients holistically through the precise placement of crystals on the body and the surrounding room. This means that, unlike Western healthcare (which tends to focus on treating one symptom/ailment at a time) crystal therapy addresses the patient as a whole - paying as much attention to his or her spiritual and emotional well-being as to their physical health.\n\nThere is very little scientific evidence to support the effectiveness of crystal healing on a medical level. However, crystals have been used, revered and enjoyed for many thousands of years - both for their aesthetic beauty and for the peace, relaxation and harmony they seem to invoke.\n\nCrystal therapy is a non-invasive, relaxing, natural and enjoyable process. Whether you believe in the physical healing properties of crystals or not, the therapy itself will offer you a chance to lie back, relax and get in touch with your body's energies so you can leave feeling refreshed, restored and de-stressed - a perfect platform for improved physical health.\n\nHow Does Crystal Therapy Work?\nCrystal therapy is based on the premise that crystals can, in a sense, communicate with the energies flowing around the human body. On a microscopic level a crystal is a network of repeating geometric patterns made up of compressed ions, atoms and molecules. According to crystal therapy, every crystal has its own unique electromagnetic charge. These charges, or 'healing vibrations' are supposed to interact with the body's energy centres to remove 'blockages' and restore a healthy flow through the body and mind.\n\nCrystal therapists Mr. Amit Parikh choose crystals carefully for each individual patient as each one is believed to have a unique healing power. Crystal therapists Mr. Amit Parikh then place the chosen crystal on different areas of the body in a grid-like fashion designed to stimulate energy.\n\nSometimes the colour of the crystal will be chosen to correspond with the supposed colour of each energy point on the body. From the tip of the tailbone to the top of the head the colours are as follows: red, orange, yellow, green, blue, indigo and violet.\n\nCrystal therapy is a non-invasive, relaxing, natural and enjoyable process. Whether you believe in the physical healing properties of crystals or not, the therapy itself will offer you a chance to lie back, relax and get in touch with your body's energies so you can leave feeling refreshed, restored and de-stressed - a perfect platform for improved physical health.\n\nCrystals have the metaphysical power of healing. Using certain crystal methods, crystal healing can help a number of physical problems. This metaphysical healing relies on the innate powers of healing crystals.\n\nCrystal healing therapy involves placing gemstones on the body to draw out negative energy. Crystal healing is an alternative medical technique in which crystals and other stones are used to cure ailments and protect against disease.\n\nCrystal healing is a pseudoscientific alternative medicine technique that employs stones and crystals. Adherents of the technique claim that these have healing powers, although there is no scientific basis for this claim.\n\nCrystal therapy has attained unprecedented popularity among people over last few years. Given the insurmountable stress our lives encounter, people seek crystal healing against a range of physical diseases, stress and other emotional concerns. Our crystal therapy specialists closely pay attention to the concerns expressed by people before curing them. The core of this therapy lies in the healing properties ingrained in the deep core of the ancient crystals.\n\nFormed underneath the earth for millions of years, crystals exude positive vibrations around to help people attain complete wellbeing- physical, mental, emotional and spiritual. These multi-coloured crystals are found in different shapes. So those who are looking to get quality relief, then crystal therapy sets you on the right path to regain balance of your life chakras and the auras to rejuvenate your body, mind and soul. It may not have sufficient scientific evidence, but crystal therapy allows you breathe in a healthiest way. It soothes out the disturbing energies by inducing deep relaxation and eventual respite from pain.\n\nWe use appropriate crystals to relieve people from experiencing excruciating pain originated from different reasons. Crystals are often placed on the problematic areas to get excellent healing results. Many can get immediate benefits. However, our crystal therapists recommend a suitable course of treatment to get ample benefits. That is done in order to offer sustained healing under the direct supervision of the practitioners. As an unconventional and affordable therapy, our crystal therapy services have grown immensely popular among people residing in different parts of the country.\n\nYou can contact on +91 98985 44441 Or Mail On mahrshivastu@gmail.com and discuss your problem and you will receive Proper Vastu Guidance Online via email."
        // vc.vv = "http://vastushastraexperts.com/crystal-therapy-in-ahmedabad.html";
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    @IBAction func hypnosis(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesWebViewController")as! ServicesWebViewController
        vc.vv = "hypnosis.jpg"
        vc.vvv = "CRYSTAL THERAPY"
        vc.vvvv = "Hypnotherapy is a form of complementary therapy that utilises the power of positive suggestion to bring about subconscious change to our thoughts, feelings and behaviour. ... This heightened state of awareness - reached using skilled relaxation techniques - allows the therapist to then make appropriate suggestions.\n\nHow Does It Work?\n\nHypnosis is thought to work by altering our state of consciousness in such a way that the analytical left-hand side of the brain is turned off, while the non-analytical right-hand side is made more alert. The conscious control of the mind is inhibited, and the subconscious mind awoken. Since the subconscious mind is a deeper-seated, more instinctive force than the conscious mind, this is the part which has to change for the patient's behaviour and physical state to alter.\n\nWhat Problems Can Be Treated By Hypnotherapy?\n\nHypnotherapy can be applied to many psychological, emotional and physical disorders. It is used to relieve pain in surgery and dentistry and has proved to be of benefit in obstetrics. It can shorten the delivery stage of labour and reduce the need for painkillers. It can ease the suffering of the disabled and those facing terminal illness, and it has been shown to help people to overcome addictions such as smoking and alcoholism, and to help with bulimia. Children are generally easy to hypnotise and can be helped with nocturnal enuresis (bedwetting) and chronic asthma, whilst teenagers can conquer stammering or blushing problems which can otherwise make their lives miserable.\n\nPhobias of all kinds lend themselves well to hypnotherapy, and anyone suffering from panic attacks or obsessional compulsive behaviour, and stress-related problems like insomnia, may benefit. Conditions exacerbated by tension, such as irritable bowel syndrome, psoriasis and eczema, and excessive sweating, respond well, and even tinnitus and clicky jaws (tempero-mandibular joint dysfunction) can be treated by these techniques.\n\nThe Top Ten Benefits Of Hypnotherapy :\n1. Hypnosis can help treat addictions\n2. Hypnosis can help you lose weight and keep it off\n3. Hypnosis can help manage chronic pain\n4. Hypnosis can help reduce stress\n5. Hypnosis can help deal with childhood issues\n6. Hypnosis can help cure sleep disorders\n7. Hypnosis can promote deep relaxation\n8. Hypnosis can help you change your behaviour\n9. Hypnosis can help recover buried memories\n10. Hypnosis can help treat Anxiety and Depression\n\nHypnotherapy Can Improve The Success Of Other Treatments For Many Conditions, Including:\n\n•Phobias, fears, and anxiety.\n•Sleep disorders.\n•Depression.\n•Stress.\n•Post-trauma anxiety.\n•Grief and loss.\n\nPeople are becoming aware of the many benefits hypnotherapy offers to redefine your life for better. As our lives are entangled in unforeseen situations, we often find ourselves stuck up time and again, not knowing how to make things better. That's where hypnotherapy has emerged to be a functional therapy. It puts your mind in a trance to assess your subconscious mind to regain control with better functioning. We have a proven track record of attending and resolving a range of life challenges to help you attain a heightened state of self-potential. Be it personal or any professional constraints, hypnotherapy can help you realize your self-potential to gain immediate relief.\n\nOver last many years, people from different walks of life have realized how useful hypnotherapy can be to change their perspectives towards life all together. It influences your subconscious mind to improve control over how you feel, behave and eventually do. You can get significantly relieved from many of the physical and psychological ailments to achieve reinforced strength to face any hurdle.\n\nIf you are having personal discords, hypnotherapy can be a reliable solution to assess your emotional and mental conflicts in a better light. Hypnotherapy gets you a deeper insight of your deeply buried anger and hostility to bring peace and harmony in your life. Though immediate relief may not be feasible, hypnotherapists offer a suitable course of treatment for complete satisfaction. With reasonable charges, hypnotherapy fits perfectly to help you cast a better life for yourself.\n\nYou can contact on +91 98985 44441 Or Mail On mahrshivastu@gmail.com and discuss your problem and you will receive Proper Vastu Guidance Online via email."
        //vc.vv = "http://vastushastraexperts.com/hypnosis-in-ahmedabad.html";
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    @IBAction func pyravastu(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesWebViewController")as! ServicesWebViewController
        vc.vv = "pyra vastu consultancy.jpg"
        vc.vvv = "PYRA VASTU CONSULTANCY"
        vc.vvvv = "Pyra Vastu is an emerging concept in the alternative therapies to experience the real wonders of life with the infiltration of positive energies present in our universe. Inspired from the ancient belief revolving around the cosmic energy reflected by pyramids, this therapy builds a positive aura around to harmonize yourmind, body and soul. So if you are curious to unwind the tapped potential and power of pyramids, then our excusive pyra vastu services are likely to impress you abound. It removes all the vastu defects around you and your abode to invite the magical aura of cosmic energy.\n\nOver the years, this therapy has drawn the attention of people of all ages to dither away the damaging energies around to live a peaceful life. You can keep the specialized pyramids in your house or office to invite the positive energies to stimulate your chances of success and growth. Even if you have bought a new flat or plot, then cast off the evil energies by suitably placing the pyramids. In the similar vein, if an individual successfully imbibe the standing columnar wave of the chakra energy, then he or she can experience the bountiful benefits of unbounded optimism.\n\nIrrespective of the surmounting problems you have in personal or professional life, our vastu pyramids will come handy to sort your life, almost hassle free. The cohesive energy generated with the amalgam of vastushastra and pyramid vastu has the potential to shape an enriching life for you and your loved ones.\n\nYou can contact on +91 98985 44441 Or Mail On mahrshivastu@gmail.com and discuss your problem and you will receive Proper Vastu Guidance Online via email."
        //vc.vv = "http://vastushastraexperts.com/pyra-vastu-consultancy-in-ahmedabad.html";
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

}
